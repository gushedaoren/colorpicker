package com.brstory.colorpicker;


import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.listeners.ColorListener;

public class MainActivity extends Activity {

    ColorPickerView colorPickerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        colorPickerView=findViewById(R.id.colorPickerView);


    }
}
